<div class="nav-header">
            <a href="#" class="brand-logo">
                <img class="logo-abbr" src="<?php echo e(asset('./assets/images/logo.png')); ?>" alt="">
                <img class="logo-compact" src="<?php echo e(asset('./assets/images/logo-text.png')); ?>" alt="">
                <img class="brand-title" src="<?php echo e(asset('./assets/images/logo-text.png')); ?>" alt="">
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div><?php /**PATH C:\laragon\www\facture-proforma\resources\views/partials/navbar.blade.php ENDPATH**/ ?>