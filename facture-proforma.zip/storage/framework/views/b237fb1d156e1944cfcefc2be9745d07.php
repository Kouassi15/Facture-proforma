
<?php $__env->startSection('content'); ?>
<style>
    td{
        color: black !important;
    }
</style>
<div class="content-body">
    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Factures</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Listes</a></li>
                </ol>
                
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <a href="<?php echo e(route('facture.create')); ?>" class="btn btn-primary">Ajouter une facture</a>
            </div>
        </div>
        <!-- row -->
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Liste des factures</h4>
                        <!-- <a href="<?php echo e(route('client.create')); ?>" class="btn btn-success">Ajouter</a> -->
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered verticle-middle table-responsive-sm">
                                <thead>
                                    <tr>
                                        <th scope="col">N°</th>
                                        <th scope="col">Nom client</th>
                                        <th scope="col">Numero</th>
                                        <th scope="col">Objet</th>
                                        <!-- <th scope="col">Ligne</th>
                                        <th scope="col">Lieu</th> -->
                                        <th scope="col">Montant HT</th>
                                        <th scope="col">TVA</th>
                                        <th scope="col">Remise</th>
                                        <th scope="col">Montant net</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $factures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($facture->client->nom); ?></td>
                                        <td><?php echo e($facture->numero); ?></td>
                                        <td><?php echo e($facture->objet); ?></td>
                                        <!-- <td><?php echo e($facture->ligne); ?></td>
                                        <td><?php echo e($facture->lieu); ?></td> -->
                                        <td><?php echo e($facture->montant_HT); ?></td>
                                        <td><?php echo e($facture->TVA); ?></td>
                                        <td><?php echo e($facture->remise); ?></td>
                                        <td><?php echo e($facture->montant_net); ?></td>
                                        <td><?php echo e($facture->date); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('facture.delete', $facture->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <span>
                                                    <a href="<?php echo e(route('facture.generate-pdf',$facture->id)); ?>" class="mr-4"
                                                        data-toggle="tooltip" data-placement="top" title="Voir"><i
                                                            class="fa fa-eye color-muted"></i></a>
                                                    <a href="<?php echo e(route('facture.edit', $facture->id)); ?>" class="mr-4"
                                                        data-toggle="tooltip" data-placement="top" title="Éditer"><i
                                                            class="fa fa-pencil color-muted"></i></a>
                                                    <a href="#"
                                                        onclick="event.preventDefault(); document.getElementById('delete-facture-<?php echo e($facture->id); ?>').submit();"
                                                        class="btn-delete" data-toggle="tooltip" data-placement="top"
                                                        title="Supprimer"><i class="fa fa-close color-danger"></i></a>
                                                </span>
                                            </form>
                                            <form id="delete-facture-<?php echo e($facture->id); ?>"
                                                action="<?php echo e(route('facture.delete', $facture->id)); ?>" method="POST"
                                                style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\facture-proforma\resources\views/dashboard/pages/facture/index.blade.php ENDPATH**/ ?>