    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        <?php if(session('success')): ?>
            const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-right',
                iconColor: 'white',
                color: 'white',
                background: '#15C162B6',
                customClass: {
                    popup: 'colored-toast',
                },
                showConfirmButton: false,
                timer: 4000,
                timerProgressBar: true,

            })
            Toast.fire({
                text: "<?php echo e(session('success')); ?>",
                icon: "success",
            });
        <?php endif; ?>
        <?php if(session('warning')): ?>
            const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-right',
                iconColor: 'white',
                color: 'white',
                background: '#C1B615B6',
                customClass: {
                    popup: 'colored-toast',
                },
                showConfirmButton: false,
                timer: 4000,
                timerProgressBar: true,

            })
            Toast.fire({
                text: "<?php echo e(session('warning')); ?>",
                icon: "warning",
            });
        <?php endif; ?>
        <?php if(session('error')): ?>
            const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-right',
                iconColor: 'white',
                color: 'white',
                background: '#E864C5B0',
                customClass: {
                    popup: 'colored-toast',
                },
                showConfirmButton: false,
                timer: 4000,
                timerProgressBar: true,

            })

            Toast.fire({
                text: "<?php echo e(session('error')); ?>",
                icon: "error",
            });
        <?php endif; ?>
        <?php if($errors->any()): ?>
            const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-right',
                iconColor: 'white',
                color: 'white',
                background: '#E864C593',
                customClass: {
                    popup: 'colored-toast',
                },
                showConfirmButton: false,
                timer: 4000,
                timerProgressBar: true,

            })
            Toast.fire({
                icon: 'error',
                title: "<?php echo e($errors->first()); ?>",
            })
        <?php endif; ?>
    </script>
<?php /**PATH C:\xampp\htdocs\facture-proforma\resources\views/partials/script/sweetalert.blade.php ENDPATH**/ ?>