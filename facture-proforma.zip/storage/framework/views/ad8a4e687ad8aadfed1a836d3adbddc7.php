
<?php $__env->startSection('content'); ?>

<div class="content-body">
    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Factures</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Editer une facture</a>
                        </li>
                    </ol>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <a href="<?php echo e(route('facture.index')); ?>" class="btn btn-primary">Listes</a>
            </div>
        </div>
        <!-- row -->
        <div class="row">
            <div class="col-xl-12 col-xxl-12">
                <!--  -->
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Editer une facture</h4>
                    </div>
                    <div class="card-body">
                        <div class="basic-form">
                            <form method="POST" action="<?php echo e(route('facture.update',$facture->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="form-row">
                                    <!-- <div class="form-group col-md-12">
                                        <label class="
                                        
                                        _id">Client</label>
                                        <select class="form-control <?php $__errorArgs = ['client_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="selectRole" name="client_id" placeholder="Nom" value="<?php echo e(old('client_id')); ?>">
                                            <option selected disabled value>Selectionner...</option>
                                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($client->id); ?>" <?php echo e($client->id ? 'selected' : ''); ?>><?php echo e($client->nom); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['client_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback mb-3" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div> -->
                                    <?php if($facture->client->nom == "Ministere de l'environnement"): ?>
                                    <div class="row ">
                                     <div class="form-group col-md-6">
                                        <label class="editeur_id">Editeur</label>
                                        <select class="form-control <?php $__errorArgs = ['editeur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="editeur_id" placeholder="Nom" value="<?php echo e(old('editeur_id')); ?>">
                                            <option selected disabled value>Selectionner...</option>
                                            <?php $__currentLoopData = $editeurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editeur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($editeur->id); ?>" <?php echo e($editeur->id ? 'selected' : ''); ?>><?php echo e($editeur->libelle); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['editeur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback mb-3" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                     </div>
                                     <div class="form-group col-md-6">
                                        <label class="numero">Numero</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="numero" placeholder="Numero facture" value="<?php echo e($facture->numero); ?>">
                                        <?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback mb-3" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                     </div>
                                     <div class="form-group col-md-6">
                                        <label class="objet">Objet:ligne:</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['objet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="objet" placeholder="Objet" value="<?php echo e($facture->objet); ?>">
                                        <?php $__errorArgs = ['objet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback mb-3" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                     </div>
                                     <div class="form-group col-md-6">
                                        <label class="immatriculation">Immatriculation</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['immatriculation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="immatriculation" placeholder="Immatriculation" value="<?php echo e($facture->immatriculation); ?>">
                                        <?php $__errorArgs = ['immatriculation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback mb-3" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                     </div>

                                     <div class="form-group col-md-6">
                                        <label class="marque">Marque</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['marque'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="marque" placeholder="Marque" value="<?php echo e($facture->marque); ?>">
                                        <?php $__errorArgs = ['marque'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback mb-3" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                     </div>
                                     <div class="form-group col-md-6">
                                            <label class="remise">Remise</label>
                                            <input type="number"
                                                class="form-control remise <?php $__errorArgs = ['remise'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="remise" placeholder="Remise" value="<?php echo e($facture->remise); ?>">
                                            <?php $__errorArgs = ['remise'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-3" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                     </div>
                                     <div class="form-group col-md-12">
                                        <label class="date">Date</label>
                                        <input type="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="date" value="<?php echo e($facture->date); ?>">
                                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback mb-3" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                     </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if($facture->client->nom == 'Particulier'): ?>
                                    <div class="row ">
                                        <div class="form-group col-md-6">
                                            <label class="editeur_id">Editeur</label>
                                            <select class="form-control <?php $__errorArgs = ['editeur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="editeur_id" placeholder="Nom" value="<?php echo e(old('editeur_id')); ?>">
                                                <option selected disabled value>Selectionner...</option>
                                                <?php $__currentLoopData = $editeurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editeur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($editeur->id); ?>" <?php echo e($editeur->id ? 'selected' : ''); ?>><?php echo e($editeur->libelle); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['editeur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-3" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label class="objet">Objet</label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['objet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="objet" placeholder="Objet" value="<?php echo e($facture->objet); ?>">
                                            <?php $__errorArgs = ['objet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-3" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label class="immatriculation">Immatriculation</label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['immatriculation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="immatriculation" placeholder="Immatriculation" value="<?php echo e($facture->immatriculation); ?>">
                                            <?php $__errorArgs = ['immatriculation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-3" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group col-md-6">
                                            <label class="marque">Marque</label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['marque'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="marque" placeholder="Marque" value="<?php echo e($facture->marque); ?>">
                                            <?php $__errorArgs = ['marque'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-3" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                            <div class="form-group col-md-12">
                                            <label class="date">Date</label>
                                            <input type="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="date" value="<?php echo e($facture->date); ?>">
                                            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-3" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if($facture->client->nom == 'Presidence'): ?>
                                    <div class="row ">
                                        <div class="form-group col-md-6">
                                            <label class="editeur_id">Editeur</label>
                                            <select class="form-control <?php $__errorArgs = ['editeur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="editeur_id" placeholder="Nom" value="<?php echo e(old('editeur_id')); ?>">
                                                <option selected disabled value>Selectionner...</option>
                                                <?php $__currentLoopData = $editeurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editeur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($editeur->id); ?>" <?php echo e($editeur->id ? 'selected' : ''); ?>><?php echo e($editeur->libelle); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['editeur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-3" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label class="objet">Objet</label>
                                            <textarea type="text" class="form-control <?php $__errorArgs = ['objet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="objet" placeholder="Objet" value=""><?php echo e($facture->objet); ?>

                                                </textarea>
                                            <?php $__errorArgs = ['objet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-3" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label class="immatriculation">Immatriculation</label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['immatriculation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="immatriculation" placeholder="Immatriculation" value="<?php echo e($facture->immatriculation); ?>">
                                            <?php $__errorArgs = ['immatriculation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-3" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group col-md-6">
                                            <label class="marque">Marque</label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['marque'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="marque" placeholder="Marque" value="<?php echo e($facture->marque); ?>">
                                            <?php $__errorArgs = ['marque'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-3" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-6">
                                                <label class="incident">Incidents</label>
                                                <textarea class="form-control <?php $__errorArgs = ['incident'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="incident" placeholder="Incident"><?php echo e($facture->incident); ?>

                                        </textarea>
                                                <?php $__errorArgs = ['incident'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback mb-3" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label class="commentaire">Commentaires</label>
                                                <textarea class="form-control <?php $__errorArgs = ['commentaire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="commentaire" placeholder="Commentaire"><?php echo e($facture->commentaire); ?>

                                        </textarea>
                                                <?php $__errorArgs = ['commentaire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback mb-3" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        <div class="form-group col-md-6">
                                                <label class="remise">Remise</label>
                                                <input type="number"
                                                    class="form-control remise <?php $__errorArgs = ['remise'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="remise" placeholder="Remise" value="<?php echo e($facture->remise); ?>">
                                                <?php $__errorArgs = ['remise'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback mb-3" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        <div class="form-group col-md-6">
                                            <label class="date">Date</label>
                                            <input type="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="date" value="<?php echo e($facture->date); ?>">
                                            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-3" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <div class="box-body">
                                        <div class="justify-content-center m-4">
                                            <?php $__currentLoopData = $facture->devis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="row border border-bottom-3 border-danger p-3 m-4 rounded-3">
                                                <div class="col-md-8 mb-3">
                                                    <label for="titre" class="form-label"><?php echo e($item->titre); ?></label>
                                                    <input type="text" class="form-control " id="titre"
                                                        placeholder="<?php echo e($item->titre); ?>" name="titre[]"
                                                        value="<?php echo e($item->titre); ?>">
                                                </div>
                                                <div class="col-md-1 mt-4">

                                                </div>
                                                <div class="col-md-2 mt-10"></div>
                                                <div class="col-md-1 mt-10">
                                                    <button type="button" class="btn btn-danger deleteSection"
                                                        data-id="<?php echo e($item->id); ?>"
                                                        data-url="<?php echo e(route('facture.delete', $item->id)); ?>">
                                                        X
                                                    </button>
                                                </div>
                                                <?php $__currentLoopData = $item->factureitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="row">
                                                    <div class="col-md-5">
                                                        <label for="designation"
                                                            class="form-label fw-bold">Désignation</label>
                                                        <input type="text"
                                                            class="form-control <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            id="designation" placeholder="Désignation"
                                                            name="designation1[]"
                                                            value="<?php echo e(old('designation') ?? $element->designation); ?>"
                                                            required>
                                                        <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                    
                                                </div>
                                                <div class="col-md-3">
                                                    <label for="quantite" class="form-label fw-bold">Quantité</label>
                                                    <input type="number"
                                                        class="form-control <?php $__errorArgs = ['quantite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="quantite" placeholder="Quantité" name="quantite1[]"
                                                        value="<?php echo e(old('quantite') ?? $element->quantite); ?>" required>
                                                    <?php $__errorArgs = ['quantite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <label for="prix_unit" class="form-label fw-bold">Prix
                                                        Unitaire</label>
                                                    <input type="number"
                                                        class="form-control <?php $__errorArgs = ['prix_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="prix_unit" placeholder="Prix Unitaire" name="prix_unit1[]"
                                                        value="<?php echo e(old('prix_unit') ?? $element->prix_unit); ?>" required>
                                                    <?php $__errorArgs = ['prix_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            
                                                <div class="col-md-1 mt-4">
                                                    <button type="button" class="btn btn-danger deleteButton"
                                                        data-id="<?php echo e($element->id); ?>"
                                                        data-url="<?php echo e(route('facture.delete', $element->id)); ?>">
                                                        <i class="bx bx-trash" aria-hidden="true">X</i>
                                                    </button>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                           
                                        <!-- </div> -->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group col-md-12">
                                            <div class="box-body">
                                                <div id="devis__item"></div>
                                                <div class="d-flex justify-content-center m-4">
                                                    <div class="">
                                                        <button type="button"
                                                            class="btn btn-outline-info add__devis__btn fs-4">
                                                            Ajouter un Libelle <span
                                                                class="fa-solid fa-plus-circle"></span>
                                                        </button>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-primary">Enregistrer</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
    integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        var typeClientSelect = document.getElementById("selectRole");
        var ministereDiv = document.getElementById("ministereF");
        var particulierDiv = document.getElementById("particulierF");
        var presidenceDiv = document.getElementById("presidenceF");

        typeClientSelect.addEventListener("change", function () {
            var selectedValue = typeClientSelect.value;

            // Masquer toutes les divs
            ministereDiv.hidden = true;
            particulierDiv.hidden = true;
            presidenceDiv.hidden = true;

            // Désactiver tous les éléments de la div
            disableAllInputs(ministereDiv);
            disableAllInputs(particulierDiv);
            disableAllInputs(presidenceDiv);

            // Afficher la div correspondante
            if (selectedValue === "1") {
                ministereDiv.hidden = false;
                // Activer tous les éléments de la div sélectionnée
                enableAllInputs(ministereDiv);

            } else if (selectedValue === "2") {
                particulierDiv.hidden = false;
                // Activer tous les éléments de la div sélectionnée
                enableAllInputs(particulierDiv);
            } else if (selectedValue === "3") {
                presidenceDiv.hidden = false;
                // Activer tous les éléments de la div sélectionnée
                enableAllInputs(presidenceDiv);
            }
        });
        function disableAllInputs(container) {
            var inputs = container.getElementsByTagName("input");
            var selects = container.getElementsByTagName("select");
            var textareas = container.getElementsByTagName("textarea");
            for (var i = 0; i < inputs.length; i++) {
                inputs[i].disabled = true;
            }
            for (var i = 0; i < selects.length; i++) {
                selects[i].disabled = true;
            }
            for (var i = 0; i < textareas.length; i++) {
                textareas[i].disabled = true;
            }
        }

        // Fonction pour activer tous les éléments d'une div
        function enableAllInputs(container) {
            var inputs = container.getElementsByTagName("input");
            var selects = container.getElementsByTagName("select");
            var textareas = container.getElementsByTagName("textarea");
            for (var i = 0; i < inputs.length; i++) {
                inputs[i].disabled = false;
            }
            for (var i = 0; i < selects.length; i++) {
                selects[i].disabled = false;
            }
            for (var i = 0; i < textareas.length; i++) {
                textareas[i].disabled = false;
            }
        }
    });
    function afficherFormulaire(id) {
    // Masquer tous les formulaires
    document.getElementById('ministereF').setAttribute('hidden', 'hidden');
    document.getElementById('particulierF').setAttribute('hidden', 'hidden');
    document.getElementById('presidenceF').setAttribute('hidden', 'hidden');
    
    // Afficher le formulaire spécifié
    document.getElementById(id).removeAttribute("hidden");
  }
    $(document).ready(function () {
        "use strict";
        $('.add__devis__btn').click(function () {
            addDevis();
        });

        var TitreNbre = 0;

        function addDevis() {
            var devisSection = $("#devis__item");
            TitreNbre = devisSection.find(".border-danger").length + 1;
            var uniqueId = `${TitreNbre}`;

            devisSection.append(`<div id="${uniqueId}" class="row border border-bottom-3 border-danger p-3 m-4 rounded-3">
                <div class="col-md-8 mb-3">
                    <label for="titre" class="form-label">Titre ${TitreNbre}</label>
                    <input type="text" class="form-control " id="titre" placeholder="Titre ${TitreNbre}" name="titre[]" value="">
                </div>
                <div class="col-md-1 mt-4">
                    <button type="button" class="btn btn-primary add__items__btn">
                        <i class="bx bx-plus" aria-hidden="true">Add</i>
                    </button>
                </div>
                <div class="col-md-2 mt-10"></div>
                <div class="col-md-1 mt-10">
                <button type="button" class="btn btn-danger remove__devis__btn">
                    X
                </button>
            </div>
                <div id="renovation__item"></div>
            </div>`);

            $(".remove__devis__btn").hide();

            $(`#${uniqueId} .remove__devis__btn`).show();

            $(`#${uniqueId} .add__items__btn`).click(addItems);

            $(`#${uniqueId} .remove__devis__btn`).click(function () {
                $(this).closest(".row").remove();
                TitreNbre--;
            });
            TitreNbre++;
        }

        $(document).on("click", ".remove__devis__btn", function () {
            $(this).closest(".row").remove();

            $(".remove__devis__btn").hide();

            $(".remove__devis__btn:last").show();
        });

        function addItems() {
            var closestRenovationSection = $(this).closest(".row");
            var idTitle = closestRenovationSection.attr("id");
            console.log(idTitle);

            var titreId = closestRenovationSection.find("input[name='titre[]']").val();

            var uniqueId = `renovation__item_${Date.now()}`;
            closestRenovationSection.append(`<div id="${uniqueId}" class="row">
                <div class="col-md-5">
                    <label for="designation" class="form-label fw-bold">Désignation</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="designation" placeholder="Désignation" name="designation${idTitle}[]" value="<?php echo e(old('designation')); ?>" required>
                    <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-3">
                 <label for="quantite" class="form-label">Quantitée(s)</label>
                 <input type="number" class="form-control quantite <?php $__errorArgs = ['quantite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="quantite${idTitle}[]" placeolder="Quantitée(s)" value="<?php echo e(old('quantite[$loop->index]')); ?>">
                    <?php $__errorArgs = ['quantite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-3">
                 <label for="prix_unit" class="form-label">Prix unitaire</label>
                 <input type="number" class="form-control prix <?php $__errorArgs = ['prix_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="prix_unit${idTitle}[]" placeholder="Prix unitaire" name="prix_unit[]" value="<?php echo e(old('prix_unit[$loop->index]')); ?>">
                    <?php $__errorArgs = ['prix_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-1 mt-3">
                    <button type="button" class="btn btn-danger remove__item__btn">
                        <i class="bx bx-trash" aria-hidden="true">X</i>
                    </button>
                </div>
            </div>`);

            $(`#${uniqueId} .remove__item__btn`).click(function () {
                $(this).closest(".row").remove();
            });

            $("#formSubmit").submit(function (e) {
                e.preventDefault();

                const form = document.querySelector('#formSubmit');

                var devisCount = $("#devis__item .row").length;

                if (devisCount === 0) {
                    Swal.fire({
                        title: 'Erreur!',
                        text: 'Veuillez renseigner un titre et ces items svp !',
                        icon: 'error',
                    });
                } else {
                    Swal.fire({
                        title: 'Etes vous sûr de valider ce devis ?',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Oui',
                        cancelButtonText: 'Annuler'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            let timerInterval
                            Swal.fire({
                                title: 'Chargement!',
                                timer: 2000,
                                timerProgressBar: true,
                                didOpen: () => {
                                    form.submit();
                                },
                                willClose: () => {
                                    clearInterval(timerInterval)
                                }
                            })


                        }
                    });
                }
            });
        }

        $(document).on('click', '.deleteSection', function () {
            var deleteSection = $(this);
            Swal.fire({
                title: 'Êtes-vous sûr?',
                text: 'Vous ne pourrez pas annuler cette action!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Oui, supprimer!',
                cancelButtonText: 'Annuler'
            }).then((result) => {
                if (result.isConfirmed) {
                    let timerInterval
                    Swal.fire({
                        title: 'Chargement!',
                        timer: 2000,
                        timerProgressBar: true,
                        didOpen: () => {
                            window.location.href = deleteSection.data('url');
                        },
                        willClose: () => {
                            clearInterval(timerInterval)
                        }
                    })

                }
            });
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\facture-proforma\resources\views/dashboard/pages/facture/edit.blade.php ENDPATH**/ ?>