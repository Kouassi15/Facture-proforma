<div class="footer">
            <div class="copyright">
                <p>© 2024,KKS-TECHNOLOGIES </p>
            </div>
        </div><?php /**PATH C:\xampp\htdocs\facture-proforma\resources\views/partials/footer.blade.php ENDPATH**/ ?>