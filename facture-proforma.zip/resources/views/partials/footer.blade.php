<div class="footer">
            <div class="copyright">
                <p>© 2024,KKS-TECHNOLOGIES </p>
            </div>
        </div>