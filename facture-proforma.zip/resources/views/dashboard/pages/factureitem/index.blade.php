{{--
    @extends('dashboard.layout.app')

    @section('content')
        factureitem.index template
    @endsection
--}}