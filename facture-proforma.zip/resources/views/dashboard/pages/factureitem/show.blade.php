{{--
    @extends('dashboard.layout.app')

    @section('content')
        factureitem.show template
    @endsection
--}}