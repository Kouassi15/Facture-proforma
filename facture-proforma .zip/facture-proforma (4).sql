-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 28 mars 2024 à 09:35
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `facture-proforma`
--

-- --------------------------------------------------------

--
-- Structure de la table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE `clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`id`, `nom`, `prenom`, `contact`, `created_at`, `updated_at`) VALUES
(1, 'Ministere de l\'environnement', 'Neant', '0506874510', '2024-03-21 16:32:38', '2024-03-21 16:32:38'),
(2, 'Particulier', 'Neant', '0777422577', '2024-03-21 16:33:12', '2024-03-21 16:33:12'),
(3, 'Presidence de republique de cote d\'ivoire', 'Neant', '2754546201', '2024-03-21 16:34:26', '2024-03-21 16:34:26');

-- --------------------------------------------------------

--
-- Structure de la table `devis`
--

CREATE TABLE `devis` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `facture_id` int(11) DEFAULT NULL,
  `titre` varchar(255) DEFAULT NULL,
  `montant_total` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `devis`
--

INSERT INTO `devis` (`id`, `facture_id`, `titre`, `montant_total`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, '0', '2024-03-21 16:48:16', '2024-03-21 16:48:16'),
(2, 1, 'Article Informatique1', '0', '2024-03-21 16:48:16', '2024-03-21 16:51:04'),
(3, 1, 'Domaines', '500000', '2024-03-21 16:51:04', '2024-03-21 16:51:04'),
(4, 2, 'Fourniture informatique', '500000', '2024-03-21 17:09:37', '2024-03-21 17:09:37'),
(5, 3, 'III- PRIECE A FOURNIR', '525000', '2024-03-21 17:13:40', '2024-03-26 10:00:00'),
(6, 3, 'IV- Main d\'eouvre', '525000', '2024-03-21 17:13:40', '2024-03-26 10:00:00'),
(7, 4, NULL, '1680000', '2024-03-25 16:19:05', '2024-03-26 08:52:15'),
(10, 6, NULL, '210000', '2024-03-26 09:44:37', '2024-03-26 09:59:01'),
(12, 7, NULL, '171536', '2024-03-26 10:27:43', '2024-03-26 10:27:43'),
(13, 8, NULL, '600000', '2024-03-26 11:42:07', '2024-03-26 11:42:07'),
(14, 9, NULL, '1400929', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(15, 10, 'I - PANNES CONSTATES', '0', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(16, 10, 'II - TRAVAUX A EFFECTUER', '0', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(17, 10, 'III- PRIECE A FOURNIR', '904504', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(18, 10, 'IV - MAIN D\'OEUVRE', '90000', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(19, 11, NULL, '2660649', '2024-03-27 18:01:30', '2024-03-27 18:01:30');

-- --------------------------------------------------------

--
-- Structure de la table `editeurs`
--

CREATE TABLE `editeurs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `libelle` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `editeurs`
--

INSERT INTO `editeurs` (`id`, `libelle`, `created_at`, `updated_at`) VALUES
(1, 'Guma Logistique', '2024-03-21 16:30:38', '2024-03-21 16:30:38'),
(2, 'Guma Logistique Immobilier', '2024-03-21 16:30:38', '2024-03-21 16:30:38'),
(3, 'Adama Batili', '2024-03-21 16:30:38', '2024-03-21 16:30:38');

-- --------------------------------------------------------

--
-- Structure de la table `factures`
--

CREATE TABLE `factures` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `editeur_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `numero` varchar(255) DEFAULT NULL,
  `numero_proforma` varchar(255) DEFAULT NULL,
  `objet` varchar(255) DEFAULT NULL,
  `montant_HT` varchar(255) DEFAULT NULL,
  `TVA` varchar(255) DEFAULT NULL,
  `remise` varchar(255) DEFAULT NULL,
  `montant_net` varchar(255) DEFAULT NULL,
  `montant_lettre` varchar(255) NOT NULL,
  `lieu` varchar(255) DEFAULT NULL,
  `ligne` varchar(255) DEFAULT NULL,
  `immatriculation` varchar(255) DEFAULT NULL,
  `marque` varchar(255) DEFAULT NULL,
  `incident` varchar(255) DEFAULT NULL,
  `commentaire` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `factures`
--

INSERT INTO `factures` (`id`, `editeur_id`, `client_id`, `numero`, `numero_proforma`, `objet`, `montant_HT`, `TVA`, `remise`, `montant_net`, `montant_lettre`, `lieu`, `ligne`, `immatriculation`, `marque`, `incident`, `commentaire`, `date`, `created_at`, `updated_at`) VALUES
(9, 3, 3, NULL, 'BATN°0001 AN 2024', '- REVISION GENERALE - BALAIS ESSUIE GLACE USES - FEU ARRIERE CASSE\r\n-CLIGNOTANT DE RETROVISEUR DROIT CASSE - JET D\'EAU ESSUIE GLACE DEFECTUEUX\r\n-PARE CHOC AVANT DEGRAFE', '1400929', '252167.22', '0', '1653096.22', 'UN MILLION SIX CENT CINQUANTE TROIS MILLE QUATRE VINGT SEIZE Francs CFA', NULL, NULL, 'D 10 1007', 'TOYOTA COROLLA', '- REVISION GENERALE - BALAIS ESSUIE GLACE USES \r\n- FEU ARRIERE\r\n- CLIGNOTANT DE RETROVISEUR DROIT CASSE \r\n- JET D4EAU ESSUIE GLACE DEFECTUEUX\r\n- PARE CHOC AVANT DEGRAFE', '- REMPLACEMENT & MONTAGE BALAIS ESSUIE GLACE ,AGRAFES PAC, PAREILLE D\'EAU ESSUIE GLACE , CHROME DPC, RETROVISEUR EXTG, PLAQUETTES, ROBOTS, PLAQUETTE PROTECTION, SILENTBLOC BARRE STAB - TOLERIE', '2024-03-27', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(10, 3, 1, 'N°00126 AN 2024', 'BATN°0002 AN 2024', '614790 - AUTRE ENTRETIEN ET REPARATION DE VEHICULEE, PNEUMATIQUES', '994504', '179010.72', '0', '1173514.72', 'UN MILLION CENT SOIXANTE TREIZE MILLE CINQ CENT QUINZE Francs CFA', NULL, NULL, 'D 72 805', 'FORD ESCAPE', NULL, NULL, '2024-03-27', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(11, 3, 2, NULL, 'BATN°0003 AN 2024', 'ENTRETIEN ET REPARATION DE VEHICULE', '2660649', '478916.82', '0', '3139565.82', 'TROIS MILLIONS CENT TRENTE NEUF MILLE CINQ CENT SOIXANTE SIX Francs CFA', NULL, NULL, '6558 G8 01', 'TOYOTA  LAND CRUISER', NULL, NULL, '2024-03-27', '2024-03-27 18:01:30', '2024-03-27 18:01:30');

-- --------------------------------------------------------

--
-- Structure de la table `facture_items`
--

CREATE TABLE `facture_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `facture_id` int(11) DEFAULT NULL,
  `devis_id` int(11) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `quantite` varchar(255) DEFAULT NULL,
  `prix_unit` varchar(255) DEFAULT NULL,
  `montant_total` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `facture_items`
--

INSERT INTO `facture_items` (`id`, `facture_id`, `devis_id`, `designation`, `quantite`, `prix_unit`, `montant_total`, `created_at`, `updated_at`) VALUES
(1, NULL, 2, 'Produit1', '1', '500000', '500000', '2024-03-21 16:48:16', '2024-03-21 16:48:16'),
(2, NULL, 3, 'Produit1', '1', '500000', '500000', '2024-03-21 16:51:04', '2024-03-21 16:51:04'),
(3, NULL, 4, 'Ecran1', '1', '500000', '500000', '2024-03-21 17:09:37', '2024-03-21 17:09:37'),
(4, NULL, NULL, 'Sac de farine 20kg', '10', '30000', '300000', '2024-03-21 17:13:40', '2024-03-26 08:52:15'),
(5, NULL, 5, 'Batterie 12 V 75 AH Walis', '5', '95000', '475000', '2024-03-21 17:13:40', '2024-03-25 14:39:58'),
(6, NULL, 6, 'Nombre d\'heures', '10', '5000', '50000', '2024-03-21 17:13:40', '2024-03-26 10:02:04'),
(18, NULL, NULL, 'Machine à pétrissage', '3', '160000', '480000', '2024-03-25 16:19:05', '2024-03-26 08:52:15'),
(19, NULL, NULL, 'Fournaisee', '5', '180000', '900000', '2024-03-25 16:19:05', '2024-03-26 08:52:15'),
(23, NULL, NULL, 'Ecran1', '3', '30000', '90000', '2024-03-26 09:01:24', '2024-03-26 09:03:22'),
(24, NULL, NULL, 'Ordinateur portable', '10', '250000', '2500000', '2024-03-26 09:01:24', '2024-03-26 09:03:22'),
(25, NULL, NULL, 'Chargeurs', '11', '20000', '220000', '2024-03-26 09:01:24', '2024-03-26 09:03:22'),
(26, NULL, 10, 'Fournaises', '7', '20000', '140000', '2024-03-26 09:44:37', '2024-03-26 09:59:01'),
(27, NULL, 10, 'Article1', '5', '10000', '50000', '2024-03-26 09:44:37', '2024-03-26 09:44:37'),
(28, NULL, 10, 'Ecran11', '5', '4000', '20000', '2024-03-26 09:44:37', '2024-03-26 09:56:12'),
(29, NULL, 12, 'Appareil jet d\'eau essuie glace', '1', '35000', '35000', '2024-03-26 10:27:43', '2024-03-26 17:18:24'),
(30, NULL, 12, 'Jeu d\'agrafes du pare choc avant', '1', '16536', '16536', '2024-03-26 10:27:43', '2024-03-26 10:27:43'),
(31, NULL, 12, 'Appareil jet d\'eau essuie glace', '1', '120000', '120000', '2024-03-26 10:27:43', '2024-03-26 10:27:43'),
(32, NULL, 13, 'Chromes droit du choc avant', '1', '100000', '100000', '2024-03-26 11:42:07', '2024-03-26 13:13:20'),
(33, NULL, 13, 'Rétroviseur extérieur gauches', '1', '500000', '500000', '2024-03-26 11:42:07', '2024-03-26 12:08:24'),
(34, NULL, 14, 'JEU DE BALAIS ESSUIE GLACE', '1', '35000', '35000', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(35, NULL, 14, 'JEU D\'AGRAFES DU PARE CHOC AVANT', '1', '16536', '16536', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(36, NULL, 14, 'APPARIEL JET D\'EAU ESSUIE GLACE', '1', '120000', '120000', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(37, NULL, 14, 'CHROME DROIT DU PARE CHOC AVANT', '1', '100000', '100000', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(38, NULL, 14, 'RETROVISEUR EXTERIEUR GAUCHE', '1', '500000', '500000', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(39, NULL, 14, 'JEU DE PLAQUETTE DE FREIN ARRIERE', '1', '79847', '79847', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(40, NULL, 14, 'ROBOT DE SUSPENSION AVANT', '2', '45000', '90000', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(41, NULL, 14, 'ROBOT DE SUSPENSION ARRIERE', '2', '65987', '131974', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(42, NULL, 14, 'PLAQUE DE PROTECTION', '1', '95000', '95000', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(43, NULL, 14, 'SILENTBLOC DE BARRE STABILISATION AVANT', '2', '13257', '26514', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(44, NULL, 14, 'SILENTBLOC DE BARRE STABILISATION ARRIRE', '2', '13029', '26058', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(45, NULL, 14, 'ENS (EQUILIBRAGE ROUE - PARALELISME AVANT - ALIGNEMENT) FF', '1', '10000', '10000', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(46, NULL, 14, 'MAIN D\'OEUVRE ELECTRICITE', '4', '5000', '20000', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(47, NULL, 14, 'MAIN D\'OEUVRE SILLERIE', '0', '5000', '0', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(48, NULL, 14, 'MAIN D\'OEUVRE TOLERIE', '10', '5000', '50000', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(49, NULL, 14, 'MAIN D\'OEUVRE MECANIQUE', '20', '5000', '100000', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(50, NULL, 14, 'MAIN D\'OEUVRE PEINTURE', '0', '8316', '0', '2024-03-27 09:59:54', '2024-03-27 09:59:54'),
(51, NULL, 15, 'Moyeu de roue avant usés - Batterie use - Embout & Biellette de crémaillère  défectueux -  silentbloc de bras avant usés - pare choc avant dégradé & réglage technique', '0', '0', '0', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(52, NULL, 16, 'Remplacement et montage des pièces ci-dessous citées', '0', '0', '0', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(53, NULL, 17, 'MOYEU DE ROUE AVANT', '2', '168420', '336840', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(54, NULL, 17, 'BATTERIE 12 V 75 AH WALIS', '1', '95000', '95000', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(55, NULL, 17, 'BIELLETTE DE CREMAILLERE', '2', '76756', '153512', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(56, NULL, 17, 'EMBOUT DE CREMAILLERE', '2', '87928', '175856', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(57, NULL, 17, 'GROS SILENTBLOCS BRAS AVANT', '2', '23651', '47302', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(58, NULL, 17, 'PETIT SILENTBLOCS BRAS AVANT', '2', '20162', '40324', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(59, NULL, 17, 'JEU AGRFES PARE CHOC ARRIERE', '1', '16170', '16170', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(60, NULL, 17, 'PARALLELISME AVANT', '1', '12500', '12500', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(61, NULL, 17, 'ALIGNEMENT ARRIERE', '1', '17000', '17000', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(62, NULL, 17, 'EQUILIBRAGE DES ROUES', '4', '2500', '10000', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(63, NULL, 18, 'Nombre d\'heure', '18', '5000', '90000', '2024-03-27 14:11:57', '2024-03-27 14:11:57'),
(64, NULL, 19, 'KIT DE COURROIRE DE DISTRIBUTION', '1', '216420', '216420', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(65, NULL, 19, 'COURROIRE D4AL TERNATEUR', '1', '86461', '86461', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(66, NULL, 19, 'GALET TENDEUR DE COURROIRE D\'ALTEERNATEUR', '1', '165333', '165333', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(67, NULL, 19, 'GALET ENROULEUR DE COURROIRE D\'LTERNATEUR', '1', '96270', '96270', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(68, NULL, 19, 'JOINT SPRIRE D\'ARBRE A CAME', '1', '20103', '20103', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(69, NULL, 19, 'JOINT SPRIRE DEVIBREQUIN', '1', '26268', '26268', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(70, NULL, 19, 'BIELLETTE DE SUSPENSION AVANT', '2', '86770', '173540', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(71, NULL, 19, 'AMORTISSEUR AVANT', '2', '328415', '656830', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(72, NULL, 19, 'SILENTBLOC DE BARRE STABILISATRICE', '2', '14310', '28620', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(73, NULL, 19, 'ROTULE DE DIRECTION', '2', '97611', '195222', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(74, NULL, 19, 'BIELLETTE DE SUSPENSION AVANT', '2', '85964', '171928', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(75, NULL, 19, 'AMORTISSEUR ARRIERE', '2', '285791', '571582', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(76, NULL, 19, 'SILENTBLOC DE BARRE STABILIASTRICE', '2', '14010', '28020', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(77, NULL, 19, 'HIULE DE VERIN DE SUSPENSION', '2', '16876', '33752', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(78, NULL, 19, 'HUILE DE BOITE DE TRANSFERT', '2', '6800', '13600', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(79, NULL, 19, 'HUILE DE PONT AVANT  - ARRIRE', '4', '6800', '27200', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(80, NULL, 19, 'PARALLELISME AVANT', '1', '12500', '12500', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(81, NULL, 19, 'ALIGNEMENT ARRIERE', '1', '17000', '17000', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(82, NULL, 19, 'EQUILIBRAGE  DE ROUE', '4', '2500', '10000', '2024-03-27 18:01:30', '2024-03-27 18:01:30'),
(83, NULL, 19, 'MAIN D\'OEUVRE (Nombre d\'heure', '22', '5000', '110000', '2024-03-27 18:01:30', '2024-03-27 18:01:30');

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_02_29_103336_create_clients_table', 1),
(6, '2024_02_29_103619_create_factures_table', 1),
(7, '2024_02_29_105658_create_admins_table', 1),
(8, '2024_03_04_163439_create_facture_items_table', 1),
(9, '2024_03_07_161725_create_devis_table', 1),
(10, '2024_03_13_173007_create_voitures_table', 1),
(11, '2024_03_14_093035_create_editeurs_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@gmail.com', '2024-03-21 16:29:52', '$2y$12$rG9l8bcqruICxOTEfG0L6eq.fuikCGHqJEaTL.83UFM20z2ljtK2y', 'vwBFIOmC9d', '2024-03-21 16:29:53', '2024-03-21 16:29:53');

-- --------------------------------------------------------

--
-- Structure de la table `voitures`
--

CREATE TABLE `voitures` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admins_user_id_foreign` (`user_id`);

--
-- Index pour la table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `devis`
--
ALTER TABLE `devis`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `editeurs`
--
ALTER TABLE `editeurs`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `factures`
--
ALTER TABLE `factures`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `facture_items`
--
ALTER TABLE `facture_items`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Index pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Index pour la table `voitures`
--
ALTER TABLE `voitures`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `devis`
--
ALTER TABLE `devis`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT pour la table `editeurs`
--
ALTER TABLE `editeurs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `factures`
--
ALTER TABLE `factures`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `facture_items`
--
ALTER TABLE `facture_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `voitures`
--
ALTER TABLE `voitures`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `admins`
--
ALTER TABLE `admins`
  ADD CONSTRAINT `admins_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
